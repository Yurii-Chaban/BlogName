$(document).ready(function () {
    $('.fa-bars').on('click', function () {
        $('#site-navigation ').css('display', 'block');
    })
    $("a.fancybox").fancybox();
});