<div class="blog-widgets-zone">
	<?php dynamic_sidebar(); ?>
</div>