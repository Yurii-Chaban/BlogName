<form role="search" method="get" id="searchform" action="<?php echo home_url('/'); ?>">
	<div>
		<label class="screen-reader-text" for="s">Search for:</label>
		<input type="text" value="" placeholder="Search" name="s" id="s" />
		<button type="submit" class="fa fa-search" id="searchsubmit" value=""></button>
	</div>
	
</form>